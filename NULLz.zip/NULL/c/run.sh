#!/bin/bash

echo `git add .`
echo `git commit -m "shj"`
echo `git pull origin master`
echo `git push origin master`
